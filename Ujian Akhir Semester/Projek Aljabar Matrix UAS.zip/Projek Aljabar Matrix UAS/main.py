import Davie021 as pd

data = [[10, 20, 30], [40, 50, 60]]

obj = pd.Dv(data)

print(obj.tampilkan())
print("Shape :", obj.dimensi)
print("type :", obj.tipe_data)