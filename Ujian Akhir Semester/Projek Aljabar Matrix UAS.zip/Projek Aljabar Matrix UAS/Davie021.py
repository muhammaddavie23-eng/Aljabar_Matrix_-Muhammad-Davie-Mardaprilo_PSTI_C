class Dv:

    def __init__(self, values):
        self.values = values
        self.dimensi = self.hitung_shape(values)
        self.tipe_data = self.cari_type(values)

    def hitung_shape(self, data):
        ukuran = []

        while isinstance(data, list):
            ukuran.append(len(data))
            data = data[0]

        return tuple(ukuran)

    def tampilkan(self):
        teks = ""
        for item in self.values:
            teks += f"{item}\n"
        return teks

    def cari_type(self, data):
        elemen = data

        while isinstance(elemen, list):
            elemen = elemen[0]

        return type(elemen).__name__